import { Component } from '@angular/core';

import { EventsList } from "./events/events-list/events-list";

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  imports: [EventsList],
  // template:`<h1>Welcome To Bangalore!</h1>
  //           <hr/>
  //           <h6>Bosch Office!</h6>`
})
export class App {
  protected readonly title: string = "Welcome To Bosch Events Portal!";
  protected readonly subTitle: string = "Designed & Developed by Bosch Employees!";
  // protected anotherTitle: string = "Welcome To Bosch Bangalore!";
  // protected customHtml: string = "Hello, <script><alert>You have been hacked!!</alert></script> Welcome To Bosch!";
  // protected isDisabled: boolean = false;
  // protected changeTitle(): void {
  //   this.anotherTitle = "Welcome To Bosch Hyderabad!";
  // }
}
