import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Event } from "../event-model";

import { MultiLingualDatePipe } from '../../shared/multi-lingual-date-pipe';


@Component({
  selector: 'bosch-event-details',
  imports: [CommonModule,MultiLingualDatePipe],
  templateUrl: './event-details.html',
  styleUrl: './event-details.css'
})
export class EventDetails {
  protected readonly title: string = "Details Of - ";
  @Input() event: Event;
  @Output() sendMessage: EventEmitter<string> = new EventEmitter<string>();

  onMessageSend():void{
    this.sendMessage.emit(`Processed the event with Id - ${this.event.eventId}!`)
  }

}
