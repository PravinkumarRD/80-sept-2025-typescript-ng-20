import { Component } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

import { NgxPaginationModule } from "ngx-pagination";

import { Event } from "../event-model";

import { EventDetails } from '../event-details/event-details';

import { MultiLingualDatePipe } from '../../shared/multi-lingual-date-pipe';

@Component({
  selector: 'bosch-events-list',
  imports: [EventDetails, CommonModule, MultiLingualDatePipe, FormsModule, NgxPaginationModule],
  templateUrl: './events-list.html',
  styleUrl: './events-list.css'
})
export class EventsList {
  protected readonly title: string = "Welcome To Bosch Events List!";
  protected readonly subTitle: string = "Published by Bosch Hr! India!";
  protected readonly columns: string[] = ["Event Code", "Event Name", "Start Date", "Fees"];
  protected events: Event[] = [
    {
      eventId: 1001,
      eventCode: 'SEMJQ3',
      eventName: 'Seminar on jQuery 3.x',
      description: 'Seminar will discuss all the new features of jQuery 3.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 800,
      seatsFilled: 70,
      logo: 'assets/images/jq3.png'
    },
    {
      eventId: 1002,
      eventCode: 'SEMNG1',
      eventName: 'Seminar on Angular JS 1.5.x',
      description: 'Seminar will discuss all the new features of Angular JS 1.5.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 600,
      seatsFilled: 50,
      logo: 'assets/images/ng1.png'
    },
    {
      eventId: 1003,
      eventCode: 'SEMNG2',
      eventName: 'Seminar on Angular 2.x',
      description: 'Seminar will discuss all the new features of Angular 2.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 1000,
      seatsFilled: 80,
      logo: 'assets/images/ng2.png'
    },
    {
      eventId: 1004,
      eventCode: 'SEMNG4',
      eventName: 'Seminar on Angular 4.x',
      description: 'Seminar will discuss all the new features of Angular 4.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 1000,
      seatsFilled: 76,
      logo: 'assets/images/ng2.png'
    },
    {
      eventId: 1005,
      eventCode: 'SEMBS3',
      eventName: 'Seminar on Bootstrap 3.x',
      description: 'Seminar will discuss all the new features of Bootstrap 3.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 500,
      seatsFilled: 34,
      logo: 'assets/images/bs3.png'
    }
  ];
  protected selectedEvent: Event;
  protected childMessage: string;
  protected searchChars: string;
  protected filteredEvents: Event[] = [...this.events];
  protected pageSize: number = 2;
  protected pageNumber: number = 1;
  protected onEventSelection(event: Event): void {
    this.selectedEvent = event;
  }
  protected childMessageHandler(message: string): void {
    this.childMessage = message;
  }
  protected filterData(): void {
    if (!this.searchChars || this.searchChars == '') {
      this.filteredEvents = this.events;
    } else {
      this.filteredEvents = this.events.filter(event => event.eventName.toLocaleLowerCase().includes(this.searchChars.toLocaleLowerCase()));
    }
  }
}
