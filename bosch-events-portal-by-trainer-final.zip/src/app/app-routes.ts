import { Routes } from "@angular/router";

import { tokenVerificationGuard } from "./shared/gurads/token-verification-guard";
import { roleVerificationGuard } from "./shared/gurads/role-verification-guard";

import { BoschHome } from "./home/bosch-home/bosch-home";
// import { EmployeesList } from "./employees/employees-list/employees-list";
import { EventsList } from "./events/events-list/events-list";
import { NotFound } from "./shared/not-found/not-found";
import { EventDetails } from "./events/event-details/event-details";
import { Login } from "./security/login/login";
import { RegisterEvent } from "./events/register-event/register-event";


export const routes: Routes = [
    {
        path: '',
        component: BoschHome,
        title: 'Bosch EP'
    },
    {
        path: 'home',
        component: BoschHome,
        title: 'EP Home'
    },
    {
        path: 'employees',
        loadComponent: () => import("./employees/employees-list/employees-list").then(ec => ec.EmployeesList),
        title: 'Employees List!'
    },
    {
        path: 'events',
        component: EventsList,
        title: 'Events List!',
        canActivate: [tokenVerificationGuard]
    },
    {
        path: 'events/new',
        component: RegisterEvent,
        title: 'New Event Registration!',
        canActivate: [tokenVerificationGuard, roleVerificationGuard]
    },
    {
        path: 'events/:eventId',
        component: EventDetails,
        title: 'Event Details!',
        canActivate: [tokenVerificationGuard]
    },
    {
        path: 'signin',
        component: Login,
        title: 'Bosch Login'
    },
    {
        path: '**',
        component: NotFound
    }
];