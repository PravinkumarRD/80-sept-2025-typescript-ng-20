import { Component } from '@angular/core';

import { Navbar } from './navigation/navbar/navbar';
import { Footer } from './navigation/footer/footer';
import { RouterOutlet } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  imports: [Navbar, Footer, RouterOutlet],

})
export class App {
  
}
