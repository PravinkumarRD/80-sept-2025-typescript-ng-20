import { Component, Input } from '@angular/core';

@Component({
  selector: 'bosch-employee-details',
  imports: [],
  templateUrl: './employee-details.html',
  styleUrl: './employee-details.css'
})
export class EmployeeDetails {
  protected readonly title = "Details Of - ";
  @Input() employeeName: string;
}
