import { Component } from '@angular/core';
import { EmployeeDetails } from '../employee-details/employee-details';


@Component({
  selector: 'bosch-employees-list',
  imports: [EmployeeDetails],
  templateUrl: './employees-list.html',
  styleUrl: './employees-list.css'
})
export class EmployeesList {
  protected readonly title = "Welcome To Bosch Employees List!";
  protected readonly subTitle = "List of all Indian Employees!";
  protected employeeName: string = "Pravinkumar R. D.";
}
