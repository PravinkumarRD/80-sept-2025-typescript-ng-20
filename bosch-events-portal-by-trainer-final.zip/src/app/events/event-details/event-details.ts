//import { Component, Input, Output, EventEmitter, inject, SimpleChanges } from '@angular/core';
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from "rxjs";
import { ActivatedRoute } from "@angular/router";

import { Event } from "../event-model";

import { MultiLingualDatePipe } from '../../shared/multi-lingual-date-pipe';

import { EventsApi } from "../events-api";

@Component({
  selector: 'bosch-event-details',
  imports: [CommonModule, MultiLingualDatePipe],
  templateUrl: './event-details.html',
  styleUrl: './event-details.css'
})
export class EventDetails {

  private _eventsApi = inject(EventsApi);
  private _activatedRoute = inject(ActivatedRoute);
  protected readonly title: string = "Details Of - ";
  //@Input() eventId: number;
  protected event: Event;
  //@Output() sendMessage: EventEmitter<string> = new EventEmitter<string>();

  private _eventsApiSubscription: Subscription;

  //ngOnChanges(simpleChanges: SimpleChanges): void {
  ngOnInit(): void {
    let eventId = this._activatedRoute.snapshot.params["eventId"];
    this._eventsApiSubscription = this._eventsApi.getEventDetails(eventId).subscribe(
      {
        next: data => {
          this.event = data;
        },
        error: error => {
          console.log(error)
        }
      }
    );
  }
  // onMessageSend(): void {
  //   this.sendMessage.emit(`Processed the event with Id - ${this.event.eventId}!`)
  // }
  ngOnDestroy(): void {
    if (this._eventsApiSubscription) {
      console.log('Event Details Component unsubscribed Observable!');
      this._eventsApiSubscription.unsubscribe();
    }
  }
}
