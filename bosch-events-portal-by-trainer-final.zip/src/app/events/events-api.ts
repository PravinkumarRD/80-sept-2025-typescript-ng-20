import { Injectable, inject } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Event } from "./event-model";


@Injectable({
  providedIn: 'root'
})
export class EventsApi {
  private _httpClient = inject(HttpClient);
  private _baseUrl: string = "http://localhost:9090/api";

  public getAllEvents(): Observable<Event[]> {
    return this._httpClient.get<Event[]>(`${this._baseUrl}/events`);
  }
  public getEventDetails(eventId: number): Observable<Event> {
    return this._httpClient.get<Event>(`${this._baseUrl}/events/${eventId}`);
  }
  public publishNewEvent(event: Event): Observable<Event> {
    return this._httpClient.post<Event>(`${this._baseUrl}/events`, event);
  }
}
