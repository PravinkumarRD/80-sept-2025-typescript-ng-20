import { Component, inject } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { Subscription } from "rxjs";
import { RouterLink } from '@angular/router';

import { NgxPaginationModule } from "ngx-pagination";

import { Event } from "../event-model";

// import { EventDetails } from '../event-details/event-details';

import { MultiLingualDatePipe } from '../../shared/multi-lingual-date-pipe';

import { EventsApi } from "../events-api";


@Component({
  selector: 'bosch-events-list',
  imports: [CommonModule, MultiLingualDatePipe, FormsModule, NgxPaginationModule,RouterLink],
  templateUrl: './events-list.html',
  styleUrl: './events-list.css',
  //providers:[EventsApi]
})
export class EventsList {
  private _eventsApi = inject(EventsApi);
  protected readonly title: string = "Welcome To Bosch Events List!";
  protected readonly subTitle: string = "Published by Bosch Hr! India!";
  protected readonly columns: string[] = ["Event Code", "Event Name", "Start Date", "Fees"];
  protected events: Event[];
  // protected selectedEvent: Event;
  //protected selectedEventId: number;
  protected childMessage: string;
  protected searchChars: string;
  protected filteredEvents: Event[];
  protected pageSize: number = 2;
  protected pageNumber: number = 1;

  private _eventsApiSubscription: Subscription;

  ngOnInit(): void {
    this._eventsApiSubscription = this._eventsApi.getAllEvents().subscribe(
      {
        next: data => {
          this.events = data
          this.filteredEvents = [...this.events];
        },
        error: error => {
          console.log(error)
        }
      }
    );
  }

  // protected onEventSelection(event: Event): void {
  //   this.selectedEvent = event;
  // }
  // protected onEventSelection(eventId: number): void {
  //   this.selectedEventId = eventId;
  // }
  protected childMessageHandler(message: string): void {
    this.childMessage = message;
  }
  protected filterData(): void {
    if (!this.searchChars || this.searchChars == '') {
      this.filteredEvents = this.events;
    } else {
      this.filteredEvents = this.events.filter(event => event.eventName.toLocaleLowerCase().includes(this.searchChars.toLocaleLowerCase()));
    }
    this.pageNumber = 1;
  }
  ngOnDestroy(): void {
    if (this._eventsApiSubscription) {
      console.log('Events List Component unsubscribed Observable!');
      this._eventsApiSubscription.unsubscribe();
    }
  }
}
