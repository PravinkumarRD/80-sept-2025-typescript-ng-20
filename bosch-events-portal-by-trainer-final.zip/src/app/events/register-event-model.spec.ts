import { RegisterEventModel } from './register-event-model';

describe('RegisterEventModel', () => {
  it('should create an instance', () => {
    expect(new RegisterEventModel()).toBeTruthy();
  });
});
