import { Component } from '@angular/core';
import { ReactiveFormsModule } from "@angular/forms";

import { RegisterEventModel } from "../register-event-model";


@Component({
  selector: 'bosch-register-event',
  imports: [ReactiveFormsModule],
  templateUrl: './register-event.html',
  styleUrl: './register-event.css'
})
export class RegisterEvent {
  protected title: string = "Register New Event for Bosch!";
  protected subTitle: string = "Only India Hr should perform this activity!";
  protected register: RegisterEventModel = new RegisterEventModel();

  protected handleOnSubmit():void{
    console.log(this.register.event.value);
  }
}
