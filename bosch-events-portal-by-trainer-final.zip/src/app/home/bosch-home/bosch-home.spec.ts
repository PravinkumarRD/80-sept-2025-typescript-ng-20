import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoschHome } from './bosch-home';

describe('BoschHome', () => {
  let component: BoschHome;
  let fixture: ComponentFixture<BoschHome>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BoschHome]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BoschHome);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
