import { Component } from '@angular/core';

@Component({
  selector: 'bosch-bosch-home',
  imports: [],
  templateUrl: './bosch-home.html',
  styleUrl: './bosch-home.css'
})
export class BoschHome {
  protected readonly title: string = "Welcome To Bosch Events Portal!";
  protected readonly subTitle: string = "Designed & Developed by Bosch Employees!";
}
