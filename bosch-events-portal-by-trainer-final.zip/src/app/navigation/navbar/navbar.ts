import { Component, inject } from '@angular/core';
import { RouterLink, Router } from '@angular/router';

import { getAccessToken, getRole } from "../../shared/utilities/localStorageUtilities";

@Component({
  selector: 'bosch-navbar',
  imports: [RouterLink],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {

  protected isLogged: boolean = false;
  private _router = inject(Router);
  protected isHr: boolean = false;
  ngOnInit(): void {
    this._router.events.subscribe({
      next: data => {
        let token = getAccessToken();
        let role = getRole();
        if (role === "Hr") {
          this.isHr = true;
        }
        if (token !== null) {
          this.isLogged = true;
        }
      }
    });
  }

  onSignOut(): void {
    localStorage.clear();
    this.isLogged = false;
    this.isHr = false;
  }
}
