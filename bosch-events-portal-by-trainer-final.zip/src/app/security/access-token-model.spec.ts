import { AccessTokenModel } from './access-token-model';

describe('AccessTokenModel', () => {
  it('should create an instance', () => {
    expect(new AccessTokenModel()).toBeTruthy();
  });
});
