export class AccessTokenModel {
    email:string;
    role:string;
    token:string;
}
