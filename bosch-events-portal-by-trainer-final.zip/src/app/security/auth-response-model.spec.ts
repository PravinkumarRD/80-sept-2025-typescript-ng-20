import { AuthResponseModel } from './auth-response-model';

describe('AuthResponseModel', () => {
  it('should create an instance', () => {
    expect(new AuthResponseModel()).toBeTruthy();
  });
});
