import { AccessTokenModel } from "./access-token-model";
import { RefreshTokenModel } from "./refresh-token-model";

export class AuthResponse {
    accessToken: AccessTokenModel;
    refreshToken: RefreshTokenModel;
    message?: string;
    success?: boolean;
}
