import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";

import { AuthResponse } from "../auth-response-model";
import { User } from "../user";

import { SecurityApi } from "../security-api";

import { storeAuthResponse } from "../../shared/utilities/localStorageUtilities";


@Component({
  selector: 'bosch-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  private _securityApi = inject(SecurityApi);
  private _router = inject(Router);
  private _activatedRoute = inject(ActivatedRoute);
  private _subscription: Subscription;
  private _returnUrl: string;

  protected readonly title: string = "Welcome To Bosch Security Page!";
  protected user: User = new User();
  protected authResponse: AuthResponse;
  protected authErrorMessage?: string;

  ngOnInit(): void {
    this._returnUrl = this._activatedRoute.snapshot.queryParams["returnUrl"];
  }

  protected handleAuthentication(): void {
    this._subscription = this._securityApi.checkCredential(this.user).subscribe({
      next: response => {
        this.authResponse = response;
        if (this.authResponse.accessToken?.token) {
          storeAuthResponse(this.authResponse);
          if (this._returnUrl) {
            this._router.navigate([this._returnUrl], {
              queryParams: {
                locale: "en-IN"
              }
            });
          } else {
            this._router.navigate(['/home'], {
              queryParams: {
                locale: "en-IN"
              }
            });
          }
        } else {
          this.authErrorMessage = this.authResponse.message;
          setTimeout(() => {
            this.authErrorMessage = undefined;
          }, 5000);
        }
      },
      error: error => {
        console.log(error);
      }
    });
  }
  ngOnDestroy() {
    if (this._subscription) {
      this._subscription.unsubscribe();
    }
  }
}
