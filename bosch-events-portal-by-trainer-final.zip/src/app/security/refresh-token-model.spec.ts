import { RefreshTokenModel } from './refresh-token-model';

describe('RefreshTokenModel', () => {
  it('should create an instance', () => {
    expect(new RefreshTokenModel()).toBeTruthy();
  });
});
