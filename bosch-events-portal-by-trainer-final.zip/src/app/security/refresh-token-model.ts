export class RefreshTokenModel {
    token:string;
}
