import { Injectable, inject } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { AuthResponse } from "./auth-response-model";
import { User } from "./user";

@Injectable({
  providedIn: 'root'
})
export class SecurityApi {
  private _httpClient = inject(HttpClient);
  private _baseUrl: string = "http://localhost:9090/api";
  public checkCredential(user: User): Observable<AuthResponse> {
    return this._httpClient.post<AuthResponse>(`${this._baseUrl}/users/authenticate`, user, {
      headers: {
        "Content-Type": "application/json"
      }
    });
  }

}
