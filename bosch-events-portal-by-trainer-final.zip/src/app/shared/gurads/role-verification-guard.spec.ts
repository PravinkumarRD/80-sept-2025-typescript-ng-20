import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { roleVerificationGuard } from './role-verification-guard';

describe('roleVerificationGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => roleVerificationGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
