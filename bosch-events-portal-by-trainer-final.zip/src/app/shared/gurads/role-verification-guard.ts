import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { getRole } from '../utilities/localStorageUtilities';

export const roleVerificationGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  let role = getRole();
  if (role !== "Hr") {
    router.navigate(['/signin'], {
      queryParams: {
        returnUrl: state.url
      }
    });
    return false;
  } else {
    return true;
  }
};
