import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { tokenVerificationGuard } from './token-verification-guard';

describe('tokenVerificationGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => tokenVerificationGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
