import { inject } from "@angular/core";
import { CanActivateFn, Router } from '@angular/router';

import { getAccessToken } from "../utilities/localStorageUtilities";

export const tokenVerificationGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  let token = getAccessToken();
  if (token !== null) {
    return true;
  } else {
    router.navigate(['/signin'], {
      queryParams: {
        returnUrl: state.url
      }
    });
    return false;
  }

};
