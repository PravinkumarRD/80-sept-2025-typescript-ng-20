import { HttpInterceptorFn, HttpHeaders } from '@angular/common/http';

import { getAccessToken } from "../../utilities/localStorageUtilities";

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.includes("users")) {
    const tokenRequest = req.clone({
      headers: req.headers.set("Content-Type", "application/json").append("bosch-authorization-token", `${getAccessToken()}`)
    });
    return next(tokenRequest);
  }
  return next(req);
};
