import { AuthResponse } from "../../security/auth-response-model";

export function storeAuthResponse(authResponse: AuthResponse): void {
    localStorage.setItem("email", authResponse.accessToken.email);
    localStorage.setItem("role", authResponse.accessToken.role);
    localStorage.setItem("accessToken", authResponse.accessToken.token);
    localStorage.setItem("refreshToken", authResponse.refreshToken.token);
}

export function getAccessToken(): string | null {
    return localStorage.getItem("accessToken");
}

export function getRefreshToken(): string | null {
    return localStorage.getItem("refreshToken");
}

export function getRole(): string | null {
    return localStorage.getItem("role");
}