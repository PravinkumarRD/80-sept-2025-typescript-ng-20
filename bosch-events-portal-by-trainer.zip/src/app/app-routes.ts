import { Routes } from "@angular/router";

import { BoschHome } from "./home/bosch-home/bosch-home";
import { EmployeesList } from "./employees/employees-list/employees-list";
import { EventsList } from "./events/events-list/events-list";
import { NotFound } from "./shared/not-found/not-found";
import { EventDetails } from "./events/event-details/event-details";

export const routes: Routes = [
    {
        path: '',
        component: BoschHome,
        title: 'Bosch EP'
    },
    {
        path: 'home',
        component: BoschHome,
        title: 'EP Home'
    },
    {
        path: 'employees',
        component: EmployeesList,
        title: 'Employees List!'
    },
    {
        path: 'events',
        component: EventsList,
        title: 'Events List!'
    },
    {
        path: 'events/:eventId',
        component: EventDetails,
        title: 'Event Details!'
    },
    {
        path:'**',
        component:NotFound
    }
];