import { Component } from '@angular/core';

@Component({
  selector: 'bosch-employees-list',
  imports: [],
  templateUrl: './employees-list.html',
  styleUrl: './employees-list.css'
})
export class EmployeesList {
  protected readonly title = "Welcome To Bosch Employees List!";
  protected readonly subTitle = "List of all Indian Employees!";
}
