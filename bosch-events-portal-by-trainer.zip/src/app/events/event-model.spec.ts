import { EventModel } from './event-model';

describe('EventModel', () => {
  it('should create an instance', () => {
    expect(new EventModel()).toBeTruthy();
  });
});
