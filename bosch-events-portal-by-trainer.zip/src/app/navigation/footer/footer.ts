import { Component } from '@angular/core';

@Component({
  selector: 'bosch-footer',
  imports: [],
  templateUrl: './footer.html',
  styleUrl: './footer.css'
})
export class Footer {

}
