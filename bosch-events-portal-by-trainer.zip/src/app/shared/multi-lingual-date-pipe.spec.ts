import { MultiLingualDatePipe } from './multi-lingual-date-pipe';

describe('MultiLingualDatePipe', () => {
  it('create an instance', () => {
    const pipe = new MultiLingualDatePipe();
    expect(pipe).toBeTruthy();
  });
});
