import { Component } from '@angular/core';

@Component({
  selector: 'bosch-not-found',
  imports: [],
  templateUrl: './not-found.html',
  styleUrl: './not-found.css'
})
export class NotFound {
  notFoundImage: string = "../images/not-found.png"
}
